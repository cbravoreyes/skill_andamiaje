---
name: disenar-cursos-tipo-b-moodle
description: Diseña, revisa o mejora programas pedagógicos de cursos Tipo B autodirigidos y asincrónicos en Moodle que certifican una microcompetencia mediante desempeño demostrado. Úsala ante solicitudes como "crear un curso Tipo B", "formular una microcompetencia", "organizar el curso por temas", "definir evidencia y criterios" o "preparar un curso corto certificable en Moodle". No la uses para configurar técnicamente Moodle, diseñar cursos con sesiones sincrónicas ni redactar cursos que solo acreditan asistencia.
---

# Diseñar cursos Tipo B autodirigidos en Moodle

## Propósito y límites

Construir un programa pedagógico coherente para un curso Tipo B: autodirigido, asincrónico, sin sesiones sincrónicas y orientado a certificar una microcompetencia por medio de un desempeño observable.

Mantener Moodle como entorno de aprendizaje, seguimiento, entrega, consulta, retroalimentación y evaluación. No incluir instrucciones de administración, instalación, plugins, matriculación, calificador ni configuración técnica salvo que el usuario amplíe expresamente el alcance.

## Principio rector

Aplicar siempre esta cadena de alineación:

`necesidad formativa -> microcompetencia -> desempeño demostrado -> evidencia -> criterios -> temas y actividades -> evaluación -> certificación`

Cada elemento debe justificar el siguiente. No empezar por contenidos, herramientas o actividades aisladas.

## Flujo de trabajo

### 1. Recuperar o solicitar la información disponible

Identificar:

- área, asignatura o campo de formación;
- destinatarios y contexto de aplicación;
- necesidad formativa concreta;
- duración estimada de trabajo autónomo;
- plazo máximo para completar el curso;
- requisitos de ingreso, si corresponden;
- recursos necesarios para realizar el curso, si corresponden;
- versión y fecha, si corresponden.

No volver a preguntar información ya proporcionada. Cuando falte un dato decisivo, formular una pregunta breve por vez, explicar para qué sirve y ofrecer un ejemplo solo si ayuda.

### 2. Formular la microcompetencia de manera guiada

Construirla con estos componentes:

1. **Necesidad formativa:** problema o necesidad real que justifica el curso; no es la actividad ni el producto.
2. **Acción observable:** verbo que expresa un desempeño verificable.
3. **Objeto:** aquello sobre lo que recae la acción.
4. **Contenido o situación:** ámbito disciplinar o contexto en que se ejecuta.
5. **Condiciones:** requisitos de calidad, recursos, restricciones o circunstancias relevantes.

Usar la forma:

`[acción observable] + [objeto] + [contenido o situación] + [condiciones esenciales]`

Evitar `será capaz de`, `comprende`, `conoce`, `aprende`, `familiarizarse` y formulaciones centradas solo en recordar contenidos. No confundir una herramienta requerida con la competencia certificada.

Antes de continuar, comprobar que la formulación sea específica, observable, acotada para un curso corto y susceptible de evaluación mediante una evidencia concreta.

### 3. Operacionalizar la microcompetencia

Definir:

- **desempeño demostrado:** actuación integrada que permite observar la microcompetencia;
- **evidencia:** producto, ejecución o resolución concreta que conserva huellas evaluables del desempeño;
- **criterios:** cualidades observables y suficientes que determinan el logro.

Redactar criterios independientes, inequívocos y aplicables a la evidencia. No convertir los criterios en una lista de pasos ni en apreciaciones vagas como “excelente” o “adecuado” sin descriptor.

Leer [lógica pedagógica](references/logica-pedagogica.md) para aplicar las definiciones, preguntas guiadas y ejemplos. Leer [reglas de validación](references/validaciones.md) al revisar la coherencia.

### 4. Organizar el curso por temas

Derivar únicamente los temas indispensables para construir el desempeño final. No usar “Módulo 0” ni imponer una cantidad fija.

Para cada tema incluir:

- título;
- objetivo con **acción + intención pedagógica + condiciones**;
- contenidos seleccionados y organizados;
- actividad o experiencia de aprendizaje;
- recursos;
- tiempo estimado;
- evidencia o verificación del avance;
- retroalimentación.

Ordenar los temas con progresión: preparación de componentes, integración gradual y demostración final. Cada actividad debe preparar una parte del desempeño o producir información útil para mejorarlo.

### 5. Diseñar acompañamiento, evaluación y certificación

Definir un acompañamiento compatible con la modalidad autodirigida:

- orientaciones iniciales y ruta visible;
- retroalimentación automática, modelada o diferida;
- canal de consultas única y exclusivamente dentro de Moodle;
- momentos de intervención del tutor, si corresponden;
- criterios y condiciones de respuesta comunicados con claridad.

Separar:

- evaluación formativa durante los temas;
- evaluación certificadora de la evidencia final;
- decisión de certificación basada en el cumplimiento de criterios;
- oportunidades de revisión o reenvío, cuando se establezcan.

No certificar por participación, acceso, tiempo conectado o finalización de contenidos. La certificación exige evidencia suficiente del desempeño.

### 6. Entregar y revisar el programa completo

Usar [plantilla del programa](templates/programa-pedagogico-tipo-b.md) como estructura base. Adaptar los campos al caso sin eliminar los que sostienen la alineación pedagógica.

Antes de entregar:

1. revisar la cadena completa de alineación;
2. verificar que requisitos, actividades y certificación no se confundan;
3. confirmar que todos los verbos centrales sean observables;
4. distinguir duración estimada y plazo máximo;
5. comprobar que la consulta permanezca dentro de Moodle;
6. declarar como supuestos los datos que el usuario no confirmó.

Puede ejecutarse `python scripts/validar_programa.py <archivo.md>` como control estructural complementario. Sus resultados no sustituyen la revisión pedagógica.

## Reglas de interacción

- Explicar los conceptos técnicos con brevedad y lenguaje accesible.
- Formular una propuesta cuando haya información suficiente; no obligar al usuario a redactar desde cero.
- Mostrar la formulación completa después de cada ajuste sustantivo.
- Pedir confirmación antes de convertir una decisión ambigua en requisito del curso.
- No presentar una propuesta como aprobada si el usuario no la aprobó.
- Mantener el programa pedagógico separado de una posterior implementación técnica en Moodle.

## Resultado esperado

Entregar un programa listo para revisión institucional que incluya identificación, necesidad, microcompetencia, desempeño, evidencia, criterios, alcance, organización por temas, acompañamiento, evaluación y certificación, con trazabilidad explícita entre todos sus componentes.
