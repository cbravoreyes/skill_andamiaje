# Programa pedagógico de curso Tipo B

## 1. Identificación

- **Nombre del curso:**
- **Área o campo de formación:**
- **Destinatarios:**
- **Modalidad:** Tipo B, autodirigida y asincrónica, sin sesiones sincrónicas.
- **Duración estimada de trabajo autónomo:**
- **Plazo máximo de realización:**
- **Versión y fecha, si corresponde:**
- **Requisitos de ingreso, si corresponden:**
- **Recursos necesarios para realizar el curso, si corresponde:**

## 2. Necesidad formativa

[Problema, brecha o actuación que necesita fortalecerse.]

## 3. Microcompetencia

**Acción observable:**

**Objeto:**

**Contenido o situación:**

**Condiciones esenciales:**

**Formulación integrada:**

[Acción observable + objeto + contenido o situación + condiciones esenciales.]

## 4. Alcance

### Incluye

- 

### No incluye

- 

## 5. Desempeño demostrado

[Actuación integrada y observable mediante la cual se manifiesta la microcompetencia.]

## 6. Evidencia certificadora

- **Evidencia:**
- **Características de entrega:**
- **Condiciones de realización:**
- **Justificación de suficiencia:**

## 7. Criterios de logro

| N.° | Aspecto evaluado | Manifestación observable | Condición mínima de logro |
|---:|---|---|---|
| 1 |  |  |  |
| 2 |  |  |  |
| 3 |  |  |  |

## 8. Organización por temas

### Tema 1. [Título]

**Objetivo (acción + intención pedagógica + condiciones):**

**Contenidos seleccionados y organizados:**

- 

**Actividad o experiencia de aprendizaje:**

**Recursos:**

**Tiempo estimado:**

**Evidencia o verificación del avance:**

**Retroalimentación:**

### Tema 2. [Título]

**Objetivo (acción + intención pedagógica + condiciones):**

**Contenidos seleccionados y organizados:**

- 

**Actividad o experiencia de aprendizaje:**

**Recursos:**

**Tiempo estimado:**

**Evidencia o verificación del avance:**

**Retroalimentación:**

> Agregar o retirar temas según los componentes indispensables para demostrar la microcompetencia. No imponer una cantidad fija.

## 9. Ruta de aprendizaje

[Explicar la progresión desde las prácticas parciales hasta la evidencia final.]

## 10. Acompañamiento del tutor

- **Orientación inicial:**
- **Retroalimentación automática o modelada:**
- **Retroalimentación diferida:**
- **Canal de consultas:** única y exclusivamente dentro de Moodle.
- **Tiempo de respuesta:**
- **Momentos de intervención, si corresponden:**

## 11. Evaluación formativa

| Tema | Verificación o evidencia parcial | Retroalimentación | Relación con la evidencia final |
|---|---|---|---|
|  |  |  |  |

## 12. Evaluación certificadora

- **Evidencia que se valorará:**
- **Instrumento:**
- **Criterios aplicados:**
- **Regla o umbral de logro:**
- **Oportunidad de revisión o reenvío, si corresponde:**
- **Responsable de la valoración, si corresponde:**

## 13. Certificación

- **Microcompetencia que se certifica:**
- **Condición para certificar:** cumplimiento demostrado de los criterios establecidos sobre la evidencia final.
- **Resultado cuando no se alcanza el nivel:**

## 14. Matriz de alineación

| Componente de la microcompetencia | Manifestación en el desempeño | Huella en la evidencia | Criterio que lo verifica | Tema que lo prepara |
|---|---|---|---|---|
| Acción |  |  |  |  |
| Objeto |  |  |  |  |
| Contenido o situación |  |  |  |  |
| Condiciones esenciales |  |  |  |  |

## 15. Supuestos pendientes de confirmación

- Ninguno / [Enumerar los datos no confirmados que influyen en el diseño.]
