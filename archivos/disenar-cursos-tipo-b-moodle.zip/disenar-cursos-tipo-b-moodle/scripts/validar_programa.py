#!/usr/bin/env python3
"""Control estructural complementario para programas pedagógicos Tipo B."""

from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path


SECCIONES = {
    "identificación": r"^#{1,3}\s+.*identificaci[oó]n",
    "necesidad formativa": r"^#{1,3}\s+.*necesidad formativa",
    "microcompetencia": r"^#{1,3}\s+.*microcompetencia",
    "desempeño demostrado": r"^#{1,3}\s+.*desempe[nñ]o demostrado",
    "evidencia certificadora": r"^#{1,3}\s+.*evidencia",
    "criterios de logro": r"^#{1,3}\s+.*criterios",
    "organización por temas": r"^#{1,3}\s+.*organizaci[oó]n por temas",
    "acompañamiento del tutor": r"^#{1,3}\s+.*acompa[nñ]amiento",
    "evaluación formativa": r"^#{1,3}\s+.*evaluaci[oó]n formativa",
    "evaluación certificadora": r"^#{1,3}\s+.*evaluaci[oó]n certificadora",
    "certificación": r"^#{1,3}\s+.*certificaci[oó]n",
    "matriz de alineación": r"^#{1,3}\s+.*matriz de alineaci[oó]n",
}

EXPRESIONES_IMPRECISAS = (
    "será capaz de",
    "sera capaz de",
    "comprende",
    "conoce",
    "aprende",
    "familiarizarse",
)


def validar(texto: str) -> tuple[list[str], list[str]]:
    errores: list[str] = []
    advertencias: list[str] = []
    bajo = texto.lower()

    for nombre, patron in SECCIONES.items():
        if not re.search(patron, texto, flags=re.IGNORECASE | re.MULTILINE):
            errores.append(f"Falta la sección: {nombre}.")

    if not re.search(r"^#{2,4}\s+tema\s+\d+", texto, flags=re.IGNORECASE | re.MULTILINE):
        errores.append("No se encontró al menos un tema numerado.")

    if "duración estimada" not in bajo and "duracion estimada" not in bajo:
        advertencias.append("No se identifica la duración estimada de trabajo autónomo.")
    if "plazo máximo" not in bajo and "plazo maximo" not in bajo:
        advertencias.append("No se distingue el plazo máximo de realización.")
    if "dentro de moodle" not in bajo:
        advertencias.append("No se confirma que el canal de consultas permanezca dentro de Moodle.")
    if "módulo 0" in bajo or "modulo 0" in bajo:
        errores.append("La organización incluye 'Módulo 0'; el formato acordado se organiza por temas.")

    for expresion in EXPRESIONES_IMPRECISAS:
        if re.search(rf"\b{re.escape(expresion)}\b", bajo):
            advertencias.append(
                f"Revisar la expresión '{expresion}': puede ocultar un desempeño no observable."
            )

    if "acción" not in bajo and "accion" not in bajo:
        advertencias.append("No se hace explícita la acción observable de la microcompetencia.")
    if "objeto" not in bajo:
        advertencias.append("No se hace explícito el objeto de la microcompetencia.")
    if "condiciones" not in bajo:
        advertencias.append("No se hacen explícitas las condiciones de la microcompetencia.")

    return errores, advertencias


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Comprueba la estructura mínima de un programa pedagógico Tipo B en Markdown."
    )
    parser.add_argument("archivo", type=Path, help="Ruta al archivo Markdown que se validará.")
    args = parser.parse_args()

    if not args.archivo.is_file():
        print(f"ERROR: no se encontró el archivo: {args.archivo}", file=sys.stderr)
        return 2

    try:
        texto = args.archivo.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        print("ERROR: el archivo no está codificado en UTF-8.", file=sys.stderr)
        return 2

    errores, advertencias = validar(texto)

    for mensaje in errores:
        print(f"ERROR: {mensaje}")
    for mensaje in advertencias:
        print(f"AVISO: {mensaje}")

    if errores:
        print(f"Resultado: {len(errores)} error(es) y {len(advertencias)} aviso(s).")
        return 1

    print(f"Resultado: estructura mínima presente; {len(advertencias)} aviso(s).")
    print("Este control no sustituye la revisión semántica ni la validación pedagógica.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
