# Reglas de validación pedagógica

## Contenido

1. Validaciones por componente
2. Matriz de coherencia
3. Decisiones ante problemas frecuentes
4. Control final

## 1. Validaciones por componente

### Necesidad formativa

- Expresa una demanda del participante y no una actividad prescrita.
- Está vinculada con un contexto o campo identificable.
- Puede atenderse razonablemente en el alcance del curso.

### Microcompetencia

- Empieza con una acción observable.
- Identifica objeto y contexto.
- Incluye solo condiciones esenciales.
- Puede demostrarse en una evidencia concreta.
- No usa `será capaz de`, `comprende`, `conoce`, `aprende` o `familiarizarse` como verbo central.

### Desempeño demostrado

- Representa una actuación integrada y no una suma de tareas inconexas.
- Exige decisiones o aplicación en contexto.
- Mantiene el mismo alcance que la microcompetencia.

### Evidencia

- Permite observar el desempeño completo.
- Es suficiente para aplicar todos los criterios.
- Es viable de producir y entregar asincrónicamente.
- No evalúa solo memoria declarativa si la microcompetencia exige aplicación o producción.

### Criterios

- Cada criterio evalúa una cualidad distinta.
- La condición de logro es observable.
- El conjunto cubre los componentes esenciales de la microcompetencia.
- Ningún criterio introduce exigencias que no fueron enseñadas o anunciadas.
- La puntualidad o participación no sustituyen el desempeño.

### Temas

- Cada tema aporta directamente a uno o más criterios.
- El objetivo combina acción, intención pedagógica y condiciones.
- Las actividades producen práctica o evidencia de avance.
- La secuencia conduce a la integración final.
- No existe un “Módulo 0” genérico.

### Acompañamiento

- La ruta puede seguirse sin sesión sincrónica.
- El participante sabe dónde consultar y cuándo recibirá respuesta.
- Las consultas permanecen dentro de Moodle.
- Los momentos de intervención se incluyen solo si corresponden.

### Evaluación y certificación

- La evaluación formativa prepara la evidencia final.
- La evaluación certificadora aplica criterios publicados.
- Existe una regla explícita para decidir el logro.
- Completar el curso no equivale automáticamente a certificar la microcompetencia.

## 2. Matriz de coherencia

Construir esta matriz antes de cerrar el programa:

| Componente de la microcompetencia | Manifestación en el desempeño | Huella en la evidencia | Criterio que lo verifica | Tema que lo prepara |
|---|---|---|---|---|
| Acción |  |  |  |  |
| Objeto |  |  |  |  |
| Contenido o situación |  |  |  |  |
| Condiciones esenciales |  |  |  |  |

Interpretación:

- Una fila vacía indica un componente no evaluado o no enseñado.
- Un criterio sin tema asociado indica una exigencia no preparada.
- Un tema sin criterio asociado puede ser accesorio y debe justificarse o retirarse.
- Una evidencia incapaz de contener una huella requerida debe rediseñarse.

## 3. Decisiones ante problemas frecuentes

| Problema | Acción correctiva |
|---|---|
| La necesidad nombra el producto | Preguntar qué problema resuelve o qué actuación mejora ese producto. |
| La microcompetencia usa un verbo impreciso | Sustituirlo por la acción que permitiría observar ese aprendizaje. |
| La herramienta domina la formulación | Separarla como requisito, recurso o condición; recuperar el desempeño disciplinar. |
| La evidencia solo mide una parte | Ampliarla o combinar huellas relacionadas sin fragmentar el desempeño. |
| Los criterios son vagos | Nombrar el aspecto, la manifestación observable y el mínimo esperado. |
| Hay demasiados temas | Conservar solo los que preparan un criterio o componente indispensable. |
| Una actividad no aporta al desempeño | Rediseñarla como práctica deliberada o eliminarla. |
| La certificación depende de asistencia | Reemplazar esa regla por evidencia y criterios de logro. |
| Se propone videoconferencia obligatoria | Convertir la orientación o actividad a un recurso asincrónico. |

## 4. Control final

- [ ] La modalidad es autodirigida, asincrónica y sin sesiones sincrónicas.
- [ ] La necesidad antecede y justifica la microcompetencia.
- [ ] La microcompetencia contiene acción, objeto, situación y condiciones pertinentes.
- [ ] El desempeño, la evidencia y los criterios están alineados.
- [ ] El curso está organizado por temas.
- [ ] Cada objetivo de tema contiene acción, intención pedagógica y condiciones.
- [ ] Cada tema incluye contenidos, actividad, recursos, tiempo, verificación y retroalimentación.
- [ ] Se distinguen duración estimada y plazo máximo.
- [ ] Los requisitos de ingreso no se confunden con la microcompetencia.
- [ ] El acompañamiento es viable en modalidad asincrónica.
- [ ] Las consultas se realizan únicamente dentro de Moodle.
- [ ] La evaluación formativa prepara la evaluación certificadora.
- [ ] La certificación depende del cumplimiento de criterios sobre la evidencia.
- [ ] Los campos condicionales están marcados “si corresponde”.
- [ ] Los supuestos no confirmados están identificados.
