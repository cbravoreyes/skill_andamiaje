# Lógica pedagógica para cursos Tipo B

## Contenido

1. Rasgos de la modalidad
2. Formulación guiada de la microcompetencia
3. Desempeño, evidencia y criterios
4. Organización por temas
5. Acompañamiento del tutor
6. Evaluación y certificación
7. Ejemplo integrado

## 1. Rasgos de la modalidad

Un curso Tipo B es autodirigido y asincrónico. No contiene sesiones sincrónicas obligatorias. La autonomía no equivale a ausencia de orientación: el participante necesita una ruta clara, consignas autosuficientes, criterios visibles, mecanismos de retroalimentación y un canal interno de consulta.

Moodle funciona como entorno de aprendizaje, seguimiento, entrega y evaluación. El programa pedagógico define qué experiencia debe vivir el participante; no prescribe la configuración técnica de la plataforma.

La certificación acredita una microcompetencia demostrada, no la mera exposición a contenidos.

## 2. Formulación guiada de la microcompetencia

### 2.1 Área o campo

**Pregunta:** ¿Qué asignatura, área de conocimiento o campo de formación corresponde al curso?

Registrar la respuesta sin formular todavía la microcompetencia.

### 2.2 Necesidad formativa

La necesidad formativa expresa qué actuación necesita mejorar, resolver, producir o aplicar el participante. No es el nombre de una actividad ni el producto final.

**Pregunta:** ¿Qué necesidad concreta del participante desea atender con este curso?

**Ayuda:** Piense en aquello que la persona necesita realizar mejor, resolver, producir o aplicar. No indique todavía el producto que elaborará.

**Ejemplo válido:** Representar información científica mediante recursos visuales que faciliten su organización e interpretación.

**No válido:** Crear una infografía en Canva. Esto anticipa una actividad, un producto y una herramienta, pero no explica la necesidad.

**Validar que:**

- describa una brecha o demanda formativa real;
- se relacione con el área declarada;
- tenga un alcance viable para un curso corto;
- no se limite a “aprender una herramienta”.

### 2.3 Acción observable

**Pregunta:** ¿Qué acción deberá ejecutar el participante para demostrar que atendió esa necesidad?

Elegir un verbo directamente observable: analiza, diseña, argumenta, interpreta, aplica, evalúa, elabora, resuelve, integra, produce o valida, según el campo.

Evitar verbos no verificables por sí mismos: comprende, conoce, aprende, sabe o se familiariza.

### 2.4 Objeto

**Pregunta:** ¿Sobre qué objeto concreto recae la acción?

El objeto delimita el desempeño. “Analiza” es insuficiente; “analiza argumentos historiográficos” identifica qué se analiza.

### 2.5 Contenido o situación

**Pregunta:** ¿En qué contenido disciplinar, problema o situación se realiza la acción?

Esta parte evita formulaciones genéricas y conecta la microcompetencia con el contexto de aplicación.

### 2.6 Condiciones

**Pregunta:** ¿Bajo qué condiciones esenciales debe realizarse la acción?

Incluir solo condiciones que afecten el desempeño o su evaluación: fuentes requeridas, audiencia, restricciones, estándares de calidad, formato o recursos permitidos. No sobrecargar la microcompetencia con todos los detalles de la consigna.

### 2.7 Síntesis

Combinar los componentes en una oración directa:

`[verbo observable] + [objeto] + [contenido o situación] + [condiciones esenciales]`

No introducir la fórmula con “será capaz de”. La microcompetencia declara la actuación que se demuestra.

## 3. Desempeño, evidencia y criterios

### Desempeño demostrado

Describe la actuación integrada en contexto. Debe contener decisiones, aplicación y calidad observable, no una lista de contenidos estudiados.

**Pregunta:** ¿Qué actuación completa observará el evaluador para afirmar que la microcompetencia se manifiesta?

### Evidencia

Es el objeto evaluable que conserva huellas del desempeño. Puede ser un producto, una ejecución registrada o la resolución documentada de una situación.

**Pregunta:** ¿Qué entregará, realizará o resolverá el participante para que el desempeño pueda evaluarse?

Una evidencia es adecuada si es auténtica, suficiente, viable en modalidad asincrónica y compatible con los criterios.

### Criterios

Expresan las cualidades que debe mostrar la evidencia. Cada criterio debe incluir:

- un aspecto evaluado;
- una condición observable de logro;
- el nivel mínimo aceptable cuando corresponda.

Los criterios no son pasos de producción. Evitar “entregó a tiempo”, salvo que la gestión temporal forme parte real de la microcompetencia. Evitar adjetivos sin anclaje, como “creativo”, “correcto” o “excelente”.

## 4. Organización por temas

Derivar los temas a partir de los componentes necesarios para producir la evidencia final. Un tema existe porque aporta conocimientos, procedimientos o decisiones imprescindibles para el desempeño.

El objetivo de cada tema combina:

`acción observable + intención pedagógica + condiciones de ejecución`

Ejemplo: “Analiza la jerarquía de información para seleccionar y ordenar los contenidos que integrará en una representación visual, aplicando criterios de pertinencia y legibilidad”.

Cada tema contiene:

1. título;
2. objetivo;
3. contenidos seleccionados y organizados;
4. actividad o experiencia;
5. recursos;
6. tiempo estimado;
7. evidencia o verificación del avance;
8. retroalimentación.

La secuencia debe conducir desde desempeños parciales hasta la integración final. Evitar temas introductorios genéricos que no aportan a la evidencia y actividades de consumo pasivo sin verificación.

## 5. Acompañamiento del tutor

Diseñar la presencia pedagógica sin convertir el curso en sincrónico:

- bienvenida y orientación inicial autosuficiente;
- ruta de trabajo y criterios visibles desde el inicio;
- ejemplos, modelos o preguntas de autoevaluación;
- retroalimentación automática en comprobaciones cerradas;
- retroalimentación modelada mediante respuestas comentadas o listas de cotejo;
- retroalimentación diferida del tutor cuando el desempeño requiera juicio experto;
- consultas única y exclusivamente dentro de Moodle;
- momentos de intervención del tutor, si corresponden.

Definir el alcance del acompañamiento, los tiempos de respuesta y qué decisiones siguen siendo responsabilidad del participante.

## 6. Evaluación y certificación

### Evaluación formativa

Distribuir verificaciones a lo largo de los temas. Deben ofrecer información para corregir el desempeño antes de la evidencia final. Pueden incluir análisis de ejemplos, decisiones justificadas, borradores parciales, listas de cotejo y autoevaluación.

### Evaluación certificadora

Aplicar los criterios anunciados a la evidencia final. Indicar:

- instrumento de evaluación;
- criterios y descriptores;
- umbral o regla de logro;
- procedimiento de revisión o reenvío, si existe;
- responsable de la valoración, si corresponde.

### Certificación

Certificar únicamente cuando la evidencia demuestra la microcompetencia en el nivel establecido. Distinguir expresamente entre:

- completar recursos y actividades;
- entregar la evidencia;
- cumplir los criterios;
- obtener la certificación.

## 7. Ejemplo integrado

### Contexto

Área: Tecnología Educativa. Requisito de ingreso: manejo básico de Canva.

### Necesidad formativa

Representar información académica mediante recursos visuales que faciliten su organización e interpretación.

### Microcompetencia

Diseña una infografía educativa en Canva relacionada con un concepto de su asignatura, organizando la información mediante una estructura visual coherente, contenido académico pertinente y recursos gráficos que faciliten su interpretación.

### Evidencia

Infografía educativa terminada, acompañada de una breve justificación de las decisiones de organización visual y selección de recursos.

### Criterios de logro

- La estructura visual establece una jerarquía reconocible entre título, ideas principales y elementos de apoyo.
- El contenido seleccionado es académicamente pertinente y mantiene correspondencia con el concepto de la asignatura.
- Los recursos gráficos aportan significado o facilitan la interpretación; no funcionan solo como decoración.
- La composición mantiene legibilidad y coherencia entre tipografía, color, alineación y distribución espacial.

Canva es una herramienta requerida y su manejo básico es un requisito; no es, por sí solo, la microcompetencia certificada.
